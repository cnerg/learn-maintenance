import test_package

def main():
    test_package.prog.main()
